package com.betha.pedidos.model;

import java.util.Map;

public interface Parseable {
    
    void parse(Map<String, String> values);
    
}
